# Multi-Stop-Watch
Manage multiple activities using stop watches and attach notes to the activities as well. Your perfect time management tool.

Below is the screenshot showing the app working :- 

![image](https://cloud.githubusercontent.com/assets/9693472/25718789/02f4d940-3125-11e7-8c8d-fd0212a37c38.png)

![image](https://cloud.githubusercontent.com/assets/9693472/26283282/ea0338d4-3e42-11e7-880b-3622393378e7.png)


## Setting up 
1) Fork and clone the repository.
2) Open `stopWatch.html` in any modern browser.

## Contributing
1) Follow the instructions in Setting up.
2) Look for open issues or create issues.
3) Open a PR and wait for it to be reviewed!

